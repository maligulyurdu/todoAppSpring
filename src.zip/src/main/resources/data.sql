insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10001,'Mehmet Ali', 'İlk todo oluşturdum',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10002,'Ömer', 'Stajı yapasdasddsa',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10003,'Ahmet', 'H2 databasedsadsa',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10004,'Mehmet Ali', 'Spring bootasddsa',CURRENT_DATE(), false);
